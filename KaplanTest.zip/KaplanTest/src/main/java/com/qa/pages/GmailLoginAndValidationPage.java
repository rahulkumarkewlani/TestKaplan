package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;

public class GmailLoginAndValidationPage extends TestBase{
	
	@FindBy(xpath = "//input[@type='email']")
	WebElement username;
	@FindBy(xpath="//input[@class='whsOnd zHQkBf' and @type='password']")
	WebElement password;
	@FindBy(xpath="//span[@class='VfPpkd-vQzf8d' and text()='Next']")
	WebElement nextButton;
	@FindBy(xpath="//*[@name='q']")
	WebElement searchbox;
	@FindBy(xpath="//*[@class='gb_nf gb_of']")
	WebElement searchButton;
	@FindBy(xpath="//*[@class='xY a4W' and @id =':75']")
	WebElement firstMail;
	@FindBy(xpath="//*[@class='hP']")
	WebElement subjectText;
	@FindBy(xpath="//*[@class='a3s aiL ']")
	WebElement bodyText;
	
	public GmailLoginAndValidationPage(){
		PageFactory.initElements(driver, this);
	}
	public void loginAndSearchMail(String user,String pass, String searchText) throws InterruptedException {
		username.sendKeys(user);
		nextButton.click();
		password.sendKeys(pass);
		Thread.sleep(2000);
		nextButton.click();
		Thread.sleep(3000);
		searchbox.sendKeys(searchText);
		Thread.sleep(3000);
		searchButton.click();
		Thread.sleep(3000);
		firstMail.click();
		Thread.sleep(3000);
	}
	
	public String validateSubjectText() {
		return subjectText.getText();
	}
	public String validateBodyText() {
		return bodyText.getText();
	}

}
