package com.qa.testCases;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.GmailLoginAndValidationPage;

import com.qa.util.TestUtil;

public class GmailLoginAndValidationTest extends TestBase{
	
	GmailLoginAndValidationPage search; //Defining it on class level so that throughout program we can use it
	String sheetName="gmailData";
	
	public GmailLoginAndValidationTest(){
		super();  // Calling constructor of parent class i.e. Test Base
	}
	@BeforeMethod
	public void setUp() throws InterruptedException{
		initialization();
		search = new GmailLoginAndValidationPage();
		
	}
	@Test (dataProvider="getGmailTestData")
	
	public void gmailLoginValidateTest(String user, String pass, String textToSearch) throws InterruptedException{
		
		search.loginAndSearchMail(user, pass, textToSearch);
		//search.clickOnFirstMail();
		String textOfSubject=search.validateSubjectText();
		Assert.assertEquals(textOfSubject, "QATestMail");
		String textOfBody=search.validateBodyText();
		Assert.assertEquals(textOfBody, "This is QA test mail");
	}
	
		@DataProvider
		public Object[][] getGmailTestData() throws InvalidFormatException {
			Object data[][]=TestUtil.getTestData(sheetName);
			return data;
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
}